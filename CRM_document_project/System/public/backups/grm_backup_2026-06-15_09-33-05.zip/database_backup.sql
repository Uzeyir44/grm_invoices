SET NAMES 'utf8mb4';

DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_type` enum('physical','legal') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'legal',
  `fullname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `voen` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_voen` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_account` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `swift` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `beneficiary_account` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `beneficiary_voen` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `clients` VALUES('5','legal','Korovnikov Pavel Nikolayeviç','CASPİAN PİZZA MMC','1604892151','Mirzəbala Əhmədzadə, 73B','+9945574553635','Kapital Bank ASC Mərkəz filialı','200026','9900003611','AZ37NABZ01350100000000001944','AIIBAZ2XXXX','AZ16AIIB400600G9442993061102 ','2026-06-15 07:17:02','1604892151');
INSERT INTO `clients` VALUES('6','legal','Yolçuyeva Nigar Ehtibar','SQUARE MMC','1604895061','Abbas Mirzə Şərifzadə 316','+994102565080','Kapital Bank ASC Mərkəz filialı','200026','9900003611','AZ37NABZ01350100000000001944','AIIBAZ2XXXX','AZ35AIIB400600I9444881561102 ','2026-06-15 07:23:33','1604895061');
INSERT INTO `clients` VALUES('7','legal','Amil Vəliyev Samir','BSB Tam Orta İnnnovasiyalar Məktəbi','1501215221','13 Koroğlu Rəhimov küçəsi, Bakı 1072','+994102395313','ABB, SANAYE FILIALI','805603','9900001881','AZ03NABZ01350100000000002944','IBAZAZ2X','AZ27IBAZ40090019442116062211','2026-06-15 07:48:52','1501215221');
INSERT INTO `clients` VALUES('8','legal','Fətəliyev Məhəmməd Bilal','PROGATE MMC','200948217','Gülarə Qədirbəyova küçəsi, ev 14','+994107241599','KapitalBank ASC, Neftçilər filialı','201229','9900003611','AZ37NABZ01350100000000001944','AIIBAZ2XXXX','AZ36IIB400600L9441730950211','2026-06-15 07:59:17','200948217');
INSERT INTO `clients` VALUES('9','legal','Miriyev Elsan Akif','PAKSAN 2020 MMC','1505141771','Bakı şəhəri, Davud Aslan küçəsi','+994555888804','','505141','1700767721','AZ82NABZ01350100000000071944','PAHAA222','AZ27PAHA40060AZNHC0100256989','2026-06-15 08:33:24','1505141771');
INSERT INTO `clients` VALUES('10','physical','MUXTAROV VÜQAR HİDAYƏT','','1902039312','Bakı','+994505938303','“ASB” ASC Dərnəgül filialı ','504722',' 9900007981','AZ12NABZ01350100000000016944','CAPNAZ22','AZ52CAPN00000000008698100001 ','2026-06-15 09:07:36','1902039312');
INSERT INTO `clients` VALUES('11','legal','Hüseyinli Rövşən İxtiyar','EMPEROR GROUP MMC','7500975451','Bakı şəhəri, Nərimanov rayonu, Əhməd Rəcəbli küçəsi, 241B','+994 50 290 20 07','Kapital Bank ASC, Nərimanov filialı','200093','9900003611',' AZ37NABZ01350100000000001944','AIIBAZ2XXXX','AZ59AIIB400600K9440062317109','2026-06-15 09:18:46','7500975451');



DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES('1','grmgroup','$2y$10$zPpAfy4X2yjuFucrngsz8e88TULFC8G/Fzzcz.Govj4JskOcfexpG','2026-06-14 08:55:25');



